from tkinter import *
from ttkbootstrap.constants import *
import ttkbootstrap as ttkb
from frontend.homepage import *
from frontend.initialisation import *
from backend.database import *


def app():
    """
    Entry point of the application.
    """

    # Create a window using ttkbootstrap library
    root = ttkb.Window(themename='vapor')

    # Load the logo image
    global logo
    logo = PhotoImage(file=r"..\src\frontend\imgs\logo.png")

    # Set the window title, size, and position
    root.title('library management')
    root.geometry('1200x600+40+20')
    root.resizable(False, False)

    # Set the window icon
    root.iconphoto(False, logo)

    # Check if database connection is successful
    if Connect() == None:
        # If connection is not successful, initialize the frame
        initialise_frame(root)
    else:
        # If connection is successful, display the home frame
        homeframe(root)

    # Start the main event loop
    root.mainloop()


app()