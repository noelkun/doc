# Import necessary modules
from tkinter import *
from ttkbootstrap.constants import *
import ttkbootstrap as ttkb
from utilities.initialise_db import *
from frontend.homepage import *


def initialise_frame(root):
    """
    Initialises the frame for the application.

    Args:
        root: The root window to contain the frame.
    """
    initialise_frame = ttkb.Frame(root, bootstyle='dark')
    initialise_frame.pack(padx=10, pady=10, fill=BOTH, expand=TRUE)

    def initialise():
        """
        Performs the initialization process.

        - Hides the initialise_frame.
        - Calls create_db() to create the database.
        - Calls homeframe() to display the home frame.
        """
        initialise_frame.pack_forget()
        create_db()
        homeframe(root)

    initialise()