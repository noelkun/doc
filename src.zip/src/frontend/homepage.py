from tkinter import*
from ttkbootstrap.constants import*
import ttkbootstrap as ttkb
from ttkbootstrap.toast import ToastNotification
from backend.loginbackend import*
from middleware.userLibs import *
from frontend.customer import*
from frontend.admin import*
from frontend.employee import*
from backend.signupbackend import*



def homeframe(root):
    """
    Display the home frame with login buttons.

    Args:
        root: The root window.

    Returns:
        None
    """

    def loginbtn(user):
        """
        Function to handle login button clicks.

        Args:
            user: The user type (admin, member, or employee).

        Returns:
            None
        """
        home_frame.pack_forget()
        login_pg_frame(root, user)

    def adminloginbtn():
        """
        Function to handle admin login button click.

        Returns:
            None
        """
        loginbtn('admin')

    def memberloginbtn():
        """
        Function to handle member login button click.

        Returns:
            None
        """
        loginbtn('member')

    def employeeloginbtn():
        """
        Function to handle employee login button click.

        Returns:
            None
        """
        loginbtn('employee')

    global home_frame
    home_frame = ttk.Frame(root, bootstyle='dark')
    home_frame.pack(padx=10, pady=10, fill=BOTH, expand=TRUE)

    header_frame = ttk.Labelframe(home_frame, text='Welcome to FUTE libs', bootstyle='secondary')
    header_frame.pack(padx=10, pady=40, fill=X)

    login_label = ttk.Label(header_frame, text='LOGIN TO FUTElibs ', font=('Helvetica', 36), bootstyle='primary')
    login_label.pack(pady=10)

    element_frame = ttk.Labelframe(home_frame, text='LOGIN AS', bootstyle='secondary')
    element_frame.pack(padx=10, pady=5, expand=TRUE, fill=X)

    admin_b = ttk.Button(element_frame, text='ADMIN LOGIN', bootstyle='secondary-outline', command=adminloginbtn)
    admin_b.pack(side=LEFT, padx=150, pady=10)

    member_b = ttk.Button(element_frame, text='MEMBER LOGIN', bootstyle='secondary-outline', command=memberloginbtn)
    member_b.pack(side=LEFT, padx=100, pady=10)

    employee_b = ttk.Button(element_frame, text='EMPLOYEE LOGIN', bootstyle='secondary-outline', command=employeeloginbtn)
    employee_b.pack(side=LEFT, padx=150, pady=10)







def login_pg_frame(root, user):
    """
    This function creates a login page frame.

    Args:
        root: The root window object.
        user: The user object.

    Returns:
        None
    """
    User_login_frame_page = ttk.Frame(root, bootstyle='dark')
    User_login_frame_page.pack(padx=10, pady=10, expand=TRUE, fill=BOTH)

    def signupframe_bt():
        """
        This function handles the signup frame button click event.

        Returns:
        None
        """
        User_login_frame_page.pack_forget()
        signup_frame(root, user)

    def loginlogic():
        """
        Perform the login logic based on the user input.
    
        Returns:
            None
        """
        # Get the user input
        userdata = UserLibs(email=email_ent.get(), password=pass_ent.get())
    
        # Call the login function and get the result
        result = login(userdata, user)
    
        # Check if the login was successful
        if result != None:
            # Update the userdata with the result
            userdata = UserLibs(result[0], result[1], result[2], result[3], result[4])
    
            # Hide the login frame
            User_login_frame_page.pack_forget()
    
            # Show different frames based on the user type
            if user == 'member':
                toast = ToastNotification(title="FUTElibs toast message", message="login successful", duration=3000, bootstyle='success')
                toast.show_toast()
                customer_frame(root, userdata)
            elif user == 'admin':
                toast = ToastNotification(title="FUTElibs toast message", message="login successful", duration=3000, bootstyle='success')
                toast.show_toast()
                admin_frame(root, userdata)
            elif user == 'employee':
                toast = ToastNotification(title="FUTElibs toast message", message="login successful", duration=3000, bootstyle='success')
                toast.show_toast()
                employee_frame(root, userdata)
        else:
            # Update the element frame style to danger
            element_frame.configure(bootstyle='danger')
            toast = ToastNotification(title="FUTElibs toast message", message="wrong email/password", duration=3000, bootstyle='danger')
            toast.show_toast()
    
    

            
    def return_btn():
        """
        Return to the home frame.
    
        Returns:
            None
        """
        # Hide the login frame and show the home frame
        User_login_frame_page.pack_forget()
        homeframe(root)
    
    
    if user == 'member':
        lb_text = 'MEMBER LOGIN PAGE'
    elif user == 'admin':
        lb_text = 'ADMIN LOGIN PAGE'
    elif user == 'employee':
        lb_text = 'EMPLOYEE LOGIN PAGE'
    
    
    # Create the header frame
    header_frame = ttk.Labelframe(User_login_frame_page, text='WELCOME', bootstyle='secondary')
    header_frame.pack(padx=10, pady=10, fill=X)
    
    # Create the back button
    back_bt = ttk.Button(header_frame, text='BACK', bootstyle='secondary outline', command=return_btn)
    back_bt.pack(padx=5, pady=5, side=LEFT)
    
    # Create the label for the login page
    User_lin_lb = ttk.Label(header_frame, text=lb_text, font=('Helvetica', 32), bootstyle='primary')
    User_lin_lb.pack(pady=10)
    
    # Create the element frame
    element_frame = ttk.Labelframe(User_login_frame_page, text='Login', bootstyle='secondary')
    element_frame.pack(pady=30)
    
    # Create the email frame
    email_frame = ttk.Frame(element_frame)
    email_frame.pack(pady=30, padx=10, fill=BOTH)
    
    # Create the password frame
    pass_frame = ttk.Frame(element_frame)
    pass_frame.pack(pady=30, padx=10, fill=BOTH)
    
    # Create the label for the email input
    email_lb = ttk.Label(email_frame, text='Enter Email ID', font=('Helvetica', 10), bootstyle='secondary')
    email_lb.pack(side=LEFT, pady=30, padx=20)
    
    # Create the email input field
    email_ent = ttk.Entry(email_frame, font=('Helvetica', 10), bootstyle='secondary')
    email_ent.pack(pady=5, padx=10, side=RIGHT)
    
    # Create the label for the password input
    pass_lb = ttk.Label(pass_frame, text='Enter Password', font=('Helvetica', 10), bootstyle='secondary')
    pass_lb.pack(side=LEFT, pady=30, padx=20)
    
    # Create the password input field
    pass_ent = ttk.Entry(pass_frame, font=('Helvetica', 10), bootstyle='secondary', show='*')
    pass_ent.pack(pady=5, padx=10, side=RIGHT)
    
    # Create the button frame
    button_frame = ttk.Frame(element_frame)
    button_frame.pack(pady=15, padx=10, fill=Y)
    
    # Create the login button
    login_b = ttk.Button(button_frame, text='LOGIN', bootstyle='success-outline', command=loginlogic)
    login_b.pack(side=LEFT, pady=5, padx=5)
    
    # Create the signup button
    signup_b = ttk.Button(button_frame, text='SIGNUP', bootstyle='info-outline', command=signupframe_bt)
    if user == 'member':
        signup_b.pack(side=LEFT, pady=5, padx=5)



def signup_frame(root, user):
    """
    Creates and displays the signup frame.

    Args:
        root: The root window object.
        user: The user object.

    Returns:
        None.
    """
    signup_frame = ttk.Frame(root, bootstyle='dark')
    signup_frame.pack(padx=10, pady=10, fill=BOTH, expand=TRUE)

    def return_btn():
        """
        Handles the return button click event.

        Returns:
            None.
        """
        signup_frame.pack_forget()
        login_pg_frame(root, user)

    def confirm_input_fx(cname, email, passw):
        """
        Handles the confirm input function.

        Args:
            cname: The name of the user.
            email: The email of the user.
            passw: The password of the user.

        Returns:
            None.
        """
        confirm_frame = ttk.Labelframe(tcl_frame, text='CONFIRM USER CREATION QUERY', bootstyle='secondary')
        confirm_frame.pack(padx=10, pady=30, expand=TRUE, fill=BOTH)

        def submit_input_fx():
            """
            Handles the submit input function.

            Returns:
                None.
            """
            add_user(cname, email, passw, user)
            toast = ToastNotification(title="FUTElibs toast message", message="USER CREATED SUCCESSFULLY",
                                      duration=3000, bootstyle='success')
            toast.show_toast()

            
            return_btn()

        # Create the submit button
        m1=ttkb.Label(confirm_frame,text='THE FOLLOWING USER IS TO BE CREATED',font=('Helvetica',14),bootstyle='primary')
        m1.pack(padx=10,pady=10)

        # Display the user's name
        cname_lb=ttkb.Label(confirm_frame,text='  NAME: %s'%cname,font=('Helvetica',10),bootstyle='secondary')
        cname_lb.pack(padx=10,pady=10)

        # Display the user's email
        email_lb=ttkb.Label(confirm_frame,text='  EMAIL: %s'%email,font=('Helvetica',10),bootstyle='secondary')
        email_lb.pack(padx=10,pady=10)

        # Display the user's password
        passw_lb=ttkb.Label(confirm_frame,text='  PASSWORD: %s'%passw,font=('Helvetica',10),bootstyle='secondary')
        passw_lb.pack(padx=10,pady=10)

        # Create the submit button
        submit_b=ttkb.Button(confirm_frame,text='SUBMIT',bootstyle='success-outline',command=submit_input_fx)
        submit_b.pack(padx=10,pady=10)


    def cinfo_input_fx():
        

        def confirm_btn():
            """
            This function handles the confirmation of user creation.
        
            Returns:
                None.
            """
            result = check_email(email_ent.get(), user)
        
            if var_cname.get() == '':
                # Show a toast message if the user name is empty
                toast = ToastNotification(title="FUTElibs toast message", message="USER NAME CANNOT BE EMPTY",
                                          duration=3000, bootstyle='danger')
                toast.show_toast()
            elif var_email.get() == '':
                # Show a toast message if the user email is empty
                toast = ToastNotification(title="FUTElibs toast message", message="USER EMAIL CANNOT BE EMPTY",
                                          duration=3000, bootstyle='danger')
                toast.show_toast()
            elif var_pass.get() == '':
                # Show a toast message if the user password is empty
                toast = ToastNotification(title="FUTElibs toast message", message="USER PASSWORD CANNOT BE EMPTY",
                                          duration=3000, bootstyle='danger')
                toast.show_toast()
            elif result:
                # Show a toast message if the user already exists
                toast = ToastNotification(title="FUTElibs toast message", message="USER ALREADY EXISTS",
                                          duration=3000, bootstyle='danger')
                toast.show_toast()
            else:
                # Call the confirm_input_fx function with the provided arguments
                confirm_input_fx(var_cname.get(), var_email.get(), var_pass.get())

        # Create a labelframe for user info
        cinfo_input_frame = ttkb.Labelframe(tcl_frame, text='USER INFO', bootstyle='secondary')
        cinfo_input_frame.pack(padx=10, pady=20, expand=TRUE, fill=BOTH)
        
        # Create a labelframe for name input
        cname_input_frame = ttkb.Labelframe(cinfo_input_frame, text='NAME', bootstyle='secondary')
        cname_input_frame.pack(padx=10, pady=10, fill=X)
        
        # Create a label for name input
        cname_lb = ttkb.Label(cname_input_frame, text='Enter Name', font=('Helvetica', 10), bootstyle='secondary')
        cname_lb.pack(side=LEFT, padx=10, pady=10)

        # Limiting the input for name
        var_cname = StringVar()
        max_len_cname = 20
        
        def on_enter_name(*args):
            """
            Callback function to limit the length of the input for name.
            """
            s = var_cname.get()
            if len(s) > max_len_cname:
                var_cname.set(s[:max_len_cname])
        
        var_cname.trace('w', on_enter_name)


        name_ent=ttkb.Entry(cname_input_frame,textvariable=var_cname,font=('Helvetica',10),bootstyle='secondary')
        name_ent.pack(padx=10,pady=10,side=LEFT)

        email_input_frame=ttkb.Labelframe(cinfo_input_frame,text='EMAIL',bootstyle='secondary')
        email_input_frame.pack(padx=10,pady=10,fill=X)

        email_lb=ttkb.Label(email_input_frame,text='Enter Email',font=('Helvetica',10),bootstyle='secondary')
        email_lb.pack(side=LEFT,padx=10,pady=10)

        #limiting the input for email
        var_email=StringVar()

        max_len_email=25
        def on_enter_email(*args):
            """
            Sets the value of the email variable to a substring of the given email string if the length of the email string is greater than the maximum allowed length.

            Parameters:
            - args: The arguments passed to the function. No arguments are used in this function.

            Returns:
            - None
            """
            s=var_email.get()
            if len(s)>max_len_email:
                var_email.set(s[:max_len_email])

        var_email.trace('w',on_enter_email)

        email_ent=ttkb.Entry(email_input_frame,textvariable=var_email,font=('Helvetica',10),bootstyle='secondary')
        email_ent.pack(padx=10,pady=10,side=LEFT)

        pass_input_frame=ttkb.Labelframe(cinfo_input_frame,text='PASSWORD',bootstyle='secondary')
        pass_input_frame.pack(padx=10,pady=10,fill=X)

        pass_lb=ttkb.Label(pass_input_frame,text='Enter Password',font=('Helvetica',10),bootstyle='secondary')
        pass_lb.pack(side=LEFT,padx=10,pady=10)

        #limiting the input for password
        var_pass=StringVar()

        max_len_pass=20
        def on_enter_pass(*args):
            """
            Function to handle the 'on_enter_pass' event.

            Args:
                *args: Variable number of arguments.

            Returns:
                None.
            """
            s=var_pass.get()
            if len(s)>max_len_pass:
                var_pass.set(s[:max_len_pass])

        var_pass.trace('w',on_enter_pass)

        # Create a pass_ent Entry widget for password input
        pass_ent=ttkb.Entry(pass_input_frame,textvariable=var_pass,font=('Helvetica',10),bootstyle='secondary',show='*')
        pass_ent.pack(padx=10,pady=10,side=LEFT)

        # Create a cinfo_cn_bt Button widget for confirmation
        cinfo_cn_bt=ttkb.Button(cinfo_input_frame,text='CONFIRM',bootstyle='success-outline',command=confirm_btn)
        cinfo_cn_bt.pack(padx=10,pady=10,side=BOTTOM)










    if user=='admin':  # Check if the user is an admin
        lb_text='ADMIN SIGNUP'
    elif user=='member':  # Check if the user is a member
        lb_text='MEMBER SIGNUP'

    
    header_frame=ttkb.Labelframe(signup_frame,text=lb_text,bootstyle='primary')  # Create a labelframe for the header with the appropriate text
    header_frame.pack(padx=10,pady=10,fill=X)

    back_btn=ttkb.Button(header_frame,text='BACK',bootstyle='secondary-outline',command=return_btn)  # Create a button for going back
    back_btn.pack(side=LEFT,padx=10,pady=10)

    signup_label=ttkb.Label(header_frame,text=lb_text,font=('Helvetica',32),bootstyle='primary')  # Create a label for the signup text
    signup_label.pack(pady=10)

    element_frame=ttkb.Labelframe(signup_frame,text='SIGNUP',bootstyle='secondary')  # Create a labelframe for the signup elements
    element_frame.pack(padx=10,pady=5,expand=TRUE,fill=BOTH)


    tcl_frame=ScrolledFrame(element_frame,autohide=True,bootstyle='dark')  # Create a scrolled frame for the signup elements
    tcl_frame.pack(padx=5,pady=5,fill=BOTH,expand=True)


    cinfo_input_fx()  # Call the cinfo_input_fx function to handle the signup inputs
