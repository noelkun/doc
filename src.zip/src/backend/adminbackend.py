# Importing the necessary modules
from backend.database import *
import sys


def Get_book_table_data():
    """
    Retrieves data from the book table where the holder is 0.

    Returns:
        list: A list of tuples containing the book id, name, and author.
    """
    conn=None

    sql='select bid, name,author from book where holder=0'
    result=None
    try:
        # Connect to the database
        conn=Connect()
        cursor=conn.cursor()
        cursor.execute(sql)
        
        # Fetch all the rows from the query
        result=cursor.fetchall()
        
        # Close the cursor and connection
        cursor.close()
        conn.close()

    except:
        print('Error',sys.exc_info())

    finally:
        # Clean up variables
        del sql, conn
        
        # Return the result
        return result


def check_bid(bid):
    """
    Check the availability of a book by its bid.
    
    Args:
        bid (int): The ID of the book.
    
    Returns:
        tuple: A tuple containing the book's ID, name, and author if available, otherwise None.
    """
    conn=None

    # SQL query to fetch book details by bid
    sql='select bid,name,author from book where bid=%s and holder=0'
    values=(bid,)
    result=None
    try:
        # Connect to the database
        conn=Connect()
        cursor=conn.cursor()
        
        # Execute the SQL query with the provided bid
        cursor.execute(sql, values)
        
        # Fetch the first row from the result
        result=cursor.fetchone()
        
        # Close the cursor and connection
        cursor.close()
        conn.close()

    except:
        # Print the error message and stack trace
        print('Error',sys.exc_info())

    finally:
        # Clean up variables
        del values, sql, conn
        
        # Return the result
        return result


def remove_book(bid):
    """Remove book from the database by setting the holder to -1.

    Args:
        bid (int): The ID of the book to be removed.

    Raises:
        Exception: If an error occurs while removing the book.
    """
    conn = None

    # SQL query to update the 'holder' column of the 'book' table
    sql = 'UPDATE book SET holder = -1 WHERE bid = %s'
    values = (bid,)

    try:
        conn = Connect()
        cursor = conn.cursor()

        # Execute the SQL query with the given values
        cursor.execute(sql, values)

        # Commit the changes to the database
        conn.commit()

        # Close the cursor and connection
        cursor.close()
        conn.close()

    except Exception:
        # Print the error message and details
        print('Error', sys.exc_info())

    finally:
        # Clean up variables
        del values, sql, conn

def add_book(bname, auth):
    """
    Add a book to the database.

    Args:
        bname (str): The name of the book.
        auth (str): The author of the book.

    Returns:
        None
    """
    conn = None

    # SQL query to insert a new book into the 'book' table
    sql = 'insert into book values(%s,%s,%s,0)'

    # Generate a new book ID by incrementing the maximum existing ID
    bid = str(maxi()[4] + 1)

    values = (bid, bname, auth)
    
    try:
        conn = Connect()
        cursor = conn.cursor()

        # Execute the SQL query and commit the changes to the database
        cursor.execute(sql, values)
        conn.commit()

        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del values, sql, conn


"""employee dats"""



def Get_employee_table_data():
    """
    Function to retrieve employee table data.

    Returns:
        list: A list of tuples containing the employee data.
    """
    conn = None
    sql = 'select eid, name, email from employee'
    result = None

    try:
        conn = Connect()  # Establish a connection to the database
        cursor = conn.cursor()  # Create a cursor object to execute SQL statements
        cursor.execute(sql)  # Execute the SQL query
        result = cursor.fetchall()  # Fetch all the rows returned by the query
        cursor.close()  # Close the cursor
        conn.close()  # Close the connection

    except:
        print('Error', sys.exc_info())  # Print the error message if an exception occurs

    finally:
        del sql, conn  # Delete the SQL query and connection objects
        return result  # Return the result

def check_eid(eid):
    """
    Function to check if an employee ID exists in the database.

    Args:
        eid (str): The employee ID to check.

    Returns:
        tuple: A tuple containing the employee's ID, name, and email if found, otherwise None.
    """
    conn = None

    # SQL query to select employee information from the database
    sql = 'select eid, name, email from employee where eid=%s'
    values = (eid,)
    result = None
    try:
        conn = Connect()
        cursor = conn.cursor()

        # Execute the SQL query
        cursor.execute(sql, values)

        # Fetch the first row of the result
        result = cursor.fetchone()

        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del values, sql, conn

        # Return the result
        return result






def remove_employee(eid):
    """
    Removes an employee from the database.

    Args:
        eid (int): The ID of the employee to be removed.

    Returns:
        None
    """
    conn = None

    # SQL query to delete the employee from the database
    sql = """delete from employee where eid=%s"""
    values = (eid,)

    try:
        # Connect to the database
        conn = Connect()
        cursor = conn.cursor()

        # Execute the SQL query
        cursor.execute(sql, values)

        # Commit the changes
        conn.commit()

        # Close the cursor and connection
        cursor.close()
        conn.close()

    except:
        # Print error information
        print('Error', sys.exc_info())

    finally:
        # Clean up variables
        del values, sql, conn




# Function to check whether the employee email already exists
def check_email(email):
    """
    Check if the given email exists in the employee table.
    
    Args:
        email (str): The email to check.
        
    Returns:
        tuple: The first row that matches the email, or None if no match is found.
    """
    conn = None

    sql = 'SELECT * FROM employee WHERE email = %s'
    values = (email,)
    result = None
    try:
        conn = Connect()
        cursor = conn.cursor()
        cursor.execute(sql, values)
        result = cursor.fetchone()
        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del values, sql, conn
        return result

# Function to add an employee to the database
def add_employee(name, email, passw):
    """
    Add an employee to the database.

    Args:
        name (str): The name of the employee.
        email (str): The email of the employee.
        passw (str): The password of the employee.

    Returns:
        None
    """
    conn = None

    # Get the maximum employee ID from the database and increment it by 1
    eid = maxi()[2] + 1
    eid = str(eid)

    # SQL query to insert the employee into the database
    sql = 'insert into employee values(%s, %s, CURDATE(), %s, %s)'
    values = (eid, name, email, passw)

    try:
        conn = Connect()
        cursor = conn.cursor()
        
        # Execute the SQL query and commit the changes
        cursor.execute(sql, values)
        conn.commit()
        
        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del values, sql, conn